# python-project_university
i have created a university website registration page, where student,professor and admin dept can access their personal details like  
name,last name , grade in exam,their roll number at the moment any one can log in in this website but now i am working on login, logout for 
authentic users.to make this website better ,i used 5 differet type of models,views,django framework,javascript,htlm,css,MySql database
to store my data.now the website is in underconstruction hopefully i can finish it by next couple of days.please do share your suggestion to
make this website professional.

Environment:  Python 2.7, scipy, Pandas, Bugzilla, SVN, C++, Java, JQuery, MySQL, Linux, Eclipse, Shell Scripting,
HTML5/CSS. Red hat Linux, Apache,RUBY,Cassandra


